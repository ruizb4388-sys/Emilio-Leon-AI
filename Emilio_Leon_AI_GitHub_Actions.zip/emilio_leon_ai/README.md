# Emilio León AI — MVP Android

MVP Android de un asistente personal con chat, voz, historial local y configuración de API.

## Compilar APK desde GitHub (sin PC)

1. Crea un repositorio en GitHub, por ejemplo `Emilio-Leon-AI`.
2. Sube **todo el contenido de esta carpeta**, incluyendo `.github/workflows/build-apk.yml`.
3. En GitHub entra a **Actions**.
4. Selecciona **Build Emilio León AI APK**.
5. Pulsa **Run workflow** para iniciar una compilación manual. También se ejecuta automáticamente al hacer push a `main`.
6. Cuando termine con ✓ verde, abre la ejecución y busca **Artifacts**.
7. Descarga `Emilio-Leon-AI-debug-apk` desde tu celular y extrae el APK.
8. Abre `app-debug.apk` para instalarlo. Android puede pedirte autorización para instalar desde esa fuente.

## Requisitos del proyecto

- Android SDK 35
- Java 17
- Gradle 8.7
- Android Gradle Plugin 8.5.2

GitHub Actions instala Java y Gradle automáticamente; no necesitas instalar Android Studio para obtener el APK mediante Actions.

## Configurar la IA

Abre la app → **CONFIG** y coloca tu API Key, URL compatible con Chat Completions y modelo.

La API Key no está escrita en el código fuente y se guarda cifrada localmente mediante Android Keystore.

## Importante

El APK generado por este workflow es **debug**, pensado para pruebas e instalación personal. Para publicar en Google Play se deberá añadir posteriormente una firma de release y la configuración correspondiente.

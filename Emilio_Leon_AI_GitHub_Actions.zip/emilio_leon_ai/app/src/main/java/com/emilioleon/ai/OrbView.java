package com.emilioleon.ai;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.*;
import android.view.View;

public class OrbView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int state = 0; // 0 idle, 1 listening, 2 thinking, 3 responding
    private float pulse = 0;
    public OrbView(Context c, android.util.AttributeSet a) { super(c,a); setLayerType(View.LAYER_TYPE_SOFTWARE,null);
        ValueAnimator v=ValueAnimator.ofFloat(0,1); v.setDuration(1800); v.setRepeatCount(ValueAnimator.INFINITE); v.addUpdateListener(x->{pulse=(float)x.getAnimatedValue();invalidate();}); v.start(); }
    public void setState(int s){state=s;invalidate();}
    protected void onDraw(Canvas c){super.onDraw(c); float cx=getWidth()/2f, cy=getHeight()/2f; int base=Color.rgb(90,70,255); if(state==1)base=Color.rgb(30,140,255); if(state==2)base=Color.rgb(150,70,255); if(state==3)base=Color.rgb(30,220,150);
        for(int i=5;i>=1;i--){p.setStyle(Paint.Style.FILL);p.setColor(Color.argb(18+i*4,Color.red(base),Color.green(base),Color.blue(base)));c.drawCircle(cx,cy,40+i*18+pulse*7,c);} 
        p.setColor(base);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);c.drawCircle(cx,cy,55+pulse*8, p);c.drawCircle(cx,cy,76-pulse*8,p);
        p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);c.drawCircle(cx,cy,12,p);
        p.setTextAlign(Paint.Align.CENTER);p.setTextSize(13);p.setColor(Color.argb(210,255,255,255));c.drawText("EMILIO LEÓN AI",cx,cy+105,p);
    }
}

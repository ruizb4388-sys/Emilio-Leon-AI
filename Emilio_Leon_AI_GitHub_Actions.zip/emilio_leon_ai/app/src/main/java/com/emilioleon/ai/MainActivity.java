package com.emilioleon.ai;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.*;
import android.speech.*;
import android.speech.tts.TextToSpeech;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.*;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import android.util.Base64;

public class MainActivity extends Activity {
    LinearLayout messages; EditText input; TextView status; ScrollView scroll; OrbView orb; TextToSpeech tts; SpeechRecognizer sr; SharedPreferences prefs;
    static final String PREF="emilio_secure"; static final String API="api_key"; static final String BASE="base_url"; static final String MODEL="model"; static final String HISTORY="history";
    ArrayList<JSONObject> history=new ArrayList<>();

    @Override public void onCreate(Bundle b){super.onCreate(b); setContentView(R.layout.activity_main); prefs=getSharedPreferences(PREF,0); bind(); loadHistory(); setupTts(); greet();}
    void bind(){messages=findViewById(R.id.messages); input=findViewById(R.id.input); status=findViewById(R.id.status); scroll=findViewById(R.id.scroll); orb=findViewById(R.id.orb);
        findViewById(R.id.send).setOnClickListener(v->send()); findViewById(R.id.mic).setOnClickListener(v->listen()); findViewById(R.id.settings).setOnClickListener(v->settings()); findViewById(R.id.clear).setOnClickListener(v->{history.clear();prefs.edit().remove(HISTORY).apply();messages.removeAllViews();});}
    void greet(){if(history.size()==0) addBubble("Hola, soy Emilio León AI. ¿En qué puedo ayudarte?",false);}
    void addBubble(String text, boolean user){TextView tv=new TextView(this);tv.setText(text);tv.setTextColor(Color.WHITE);tv.setTextSize(16);tv.setPadding(18,14,18,14);tv.setBackgroundColor(user?Color.rgb(32,39,75):Color.rgb(20,24,40));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,6,0,6);messages.addView(tv,lp);scroll.post(()->scroll.fullScroll(View.FOCUS_DOWN));}
    void setState(int s,String label){status.setText(label);orb.setState(s);}
    void send(){String q=input.getText().toString().trim();if(q.isEmpty())return; input.setText("");addBubble(q,true); append("user",q); setState(2,"🟣 PENSANDO"); new Thread(()->callAI(q)).start();}
    void callAI(String q){try{String key=getSecret(API);if(key.isEmpty()){runOnUiThread(()->{addBubble("Configura tu API Key en ⚙ CONFIG para conectar la IA.",false);setState(0,"LISTO");});return;} String base=prefs.getString(BASE,"https://api.openai.com/v1/chat/completions");String model=prefs.getString(MODEL,"gpt-4o-mini");
            JSONArray msgs=new JSONArray(); JSONObject sys=new JSONObject();sys.put("role","system");sys.put("content","Eres Emilio León AI, un asistente personal futurista, útil y claro. Responde en español salvo que el usuario pida otro idioma.");msgs.put(sys);
            int start=Math.max(0,history.size()-12); for(int i=start;i<history.size();i++)msgs.put(history.get(i)); JSONObject body=new JSONObject();body.put("model",model);body.put("messages",msgs);body.put("temperature",0.7);
            HttpURLConnection c=(HttpURLConnection)new URL(base).openConnection();c.setRequestMethod("POST");c.setConnectTimeout(15000);c.setReadTimeout(30000);c.setDoOutput(true);c.setRequestProperty("Authorization","Bearer "+key);c.setRequestProperty("Content-Type","application/json");try(OutputStream os=c.getOutputStream()){os.write(body.toString().getBytes(StandardCharsets.UTF_8));}
            InputStream is=c.getResponseCode()<400?c.getInputStream():c.getErrorStream();String out=read(is);if(c.getResponseCode()>=400)throw new Exception(out);JSONObject r=new JSONObject(out);String ans=r.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content");append("assistant",ans);runOnUiThread(()->{addBubble(ans,false);setState(3,"🟢 RESPONDIENDO");tts.speak(ans,TextToSpeech.QUEUE_FLUSH,null,"emilio");new Handler().postDelayed(()->setState(0,"LISTO"),1200);});
        }catch(Exception e){runOnUiThread(()->{addBubble("No pude conectar con la IA: "+e.getMessage(),false);setState(0,"LISTO");});}}
    String read(InputStream is)throws Exception{BufferedReader r=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8));StringBuilder s=new StringBuilder();String l;while((l=r.readLine())!=null)s.append(l);return s.toString();}
    void append(String role,String content){try{JSONObject o=new JSONObject();o.put("role",role);o.put("content",content);history.add(o);JSONArray a=new JSONArray();for(JSONObject x:history)a.put(x);prefs.edit().putString(HISTORY,a.toString()).apply();}catch(Exception ignored){}}
    void loadHistory(){try{JSONArray a=new JSONArray(prefs.getString(HISTORY,"[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);history.add(o);addBubble(o.getString("content"),o.getString("role").equals("user"));}}catch(Exception ignored){}}
    void setupTts(){tts=new TextToSpeech(this,s->{if(s!=TextToSpeech.SUCCESS)return;tts.setLanguage(new Locale("es","PE"));});}
    void listen(){if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},5);return;}setState(1,"🔵 ESCUCHANDO"); if(!SpeechRecognizer.isRecognitionAvailable(this)){setState(0,"LISTO");return;} if(sr!=null)sr.destroy();sr=SpeechRecognizer.createSpeechRecognizer(this);sr.setRecognitionListener(new RecognitionListener(){public void onReadyForSpeech(Bundle b){}public void onBeginningOfSpeech(){}public void onRmsChanged(float r){}public void onBufferReceived(byte[] b){}public void onEndOfSpeech(){}public void onError(int e){setState(0,"LISTO");}public void onResults(Bundle b){ArrayList<String> x=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(x!=null&&!x.isEmpty()){input.setText(x.get(0));send();}}public void onPartialResults(Bundle b){}public void onEvent(int a,Bundle b){}});Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"es-PE");sr.startListening(i);}
    void settings(){final LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(30,10,30,10);EditText k=new EditText(this);k.setHint("API Key");k.setInputType(129);k.setText(getSecret(API));EditText u=new EditText(this);u.setHint("Chat Completions URL");u.setText(prefs.getString(BASE,"https://api.openai.com/v1/chat/completions"));EditText m=new EditText(this);m.setHint("Modelo");m.setText(prefs.getString(MODEL,"gpt-4o-mini"));l.addView(k);l.addView(u);l.addView(m);new AlertDialog.Builder(this).setTitle("Configuración").setMessage("La API Key se guarda cifrada con Android Keystore en este dispositivo.").setView(l).setPositiveButton("GUARDAR",(d,w)->{putSecret(API,k.getText().toString().trim());prefs.edit().putString(BASE,u.getText().toString().trim()).putString(MODEL,m.getText().toString().trim()).apply();}).setNegativeButton("CANCELAR",null).show();}
    SecretKey key(){try{KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(!ks.containsAlias("EmilioKey")){KeyGenerator g=KeyGenerator.getInstance("AES","AndroidKeyStore");g.init(256);g.generateKey();}return ((KeyStore.SecretKeyEntry)ks.getEntry("EmilioKey",null)).getSecretKey();}catch(Exception e){throw new RuntimeException(e);}}
    void putSecret(String n,String v){try{Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());byte[] iv=c.getIV(), enc=c.doFinal(v.getBytes(StandardCharsets.UTF_8));prefs.edit().putString(n,Base64.encodeToString(iv,0)+":"+Base64.encodeToString(enc,0)).apply();}catch(Exception ignored){}}
    String getSecret(String n){try{String z=prefs.getString(n,"");if(z.isEmpty())return "";String[] p=z.split(":",2);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),new javax.crypto.spec.GCMParameterSpec(128,Base64.decode(p[0],0)));return new String(c.doFinal(Base64.decode(p[1],0)),StandardCharsets.UTF_8);}catch(Exception e){return "";}}
    @Override protected void onDestroy(){if(sr!=null)sr.destroy();if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}
